plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.earnx.rewards"; compileSdk = 35
    defaultConfig { applicationId = "com.earnx.rewards"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-ads:24.7.0")
}
