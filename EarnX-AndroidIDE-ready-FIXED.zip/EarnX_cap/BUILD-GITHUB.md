# EarnX GitHub APK build

The project uses `capacitor.config.json` (not TypeScript config) to avoid the Capacitor CLI TypeScript config-loader issue.

For GitHub Actions, extract this project and run:

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug --no-daemon
```

The APK is generated at:
`android/app/build/outputs/apk/debug/app-debug.apk`
